'use strict';

define(function (require) {
	var demo = require('demo');
	var aa = demo.add(1, 3);
	console.log(aa);
});