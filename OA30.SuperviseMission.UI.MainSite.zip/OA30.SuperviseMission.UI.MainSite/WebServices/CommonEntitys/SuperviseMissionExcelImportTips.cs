﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OA30.SuperviseMission.Common.Entity.Mission;

namespace OA30.SuperviseMission.UI.MainSite.WebServices.CommonEntitys
{
    public class SuperviseMissionExcelImportTips
    {
        public string SpNumberTips { get; set; }
        public string TaskContentTips { get; set; }
        public string MainLeaderIdTips { get; set; }
        public string AssistLeaderIdTips { get; set; }
        public string MainDeptIdTips { get; set; }
        public string AssistDeptIdTips { get; set; }
    }
}