﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OA30.SuperviseMission.UI.MainSite.WebServices.CommonEntitys
{
    [Serializable]
    public class DeptNameIdList
    {
        public string DeptName { get; set; }
        public string DeptId { get; set; }
    }
}