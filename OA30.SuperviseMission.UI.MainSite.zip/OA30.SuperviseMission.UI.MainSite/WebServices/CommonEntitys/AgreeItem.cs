﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OA30.SuperviseMission.UI.MainSite.WebServices.CommonEntitys
{
    [Serializable]
    public class AgreeItem
    {
        public string smid { get; set; }
        public int flowid { get; set; }
    }
}