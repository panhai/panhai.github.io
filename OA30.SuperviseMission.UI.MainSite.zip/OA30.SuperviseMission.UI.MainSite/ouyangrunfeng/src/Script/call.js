define(function(require) {
	const demo = require('demo')
	const aa = demo.add(1,3)
	console.log(aa)
})