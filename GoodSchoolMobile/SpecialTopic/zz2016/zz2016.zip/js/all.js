(function () {

    window.isIEX = function isIEX(x){return navigator.appVersion.indexOf("MSIE "+x+".0")>0;}
    window.scriptLoad = scriptLoad;

    var htmlTemplate = '<div class="shareFixed fixed">' +
                        '<div class="in">' +
                            '<h2>点击右上角按钮分享</h2>' +
                            '<p>（看不到分享按钮？可复制此页面链接发送给好友！）</p>' +
                        '</div>' +
                    '</div>';

    if(isIEX(9) || isIEX(8) || isIEX(7)){
        scriptLoad("js/jquery.min.js", function(){

            $(".share").parent().click(function(event) {
                event.preventDefault();
                $(document.body).append(htmlTemplate);
            });
            $(document.body).delegate(".shareFixed", "click", function(event) {
                $(this).remove();
            });
        });
    }else{
        function createShare() {
         
            var dom = document.createElement('div');
            dom.innerHTML = htmlTemplate;
            
            dom.onclick= function (event) {
                document.body.removeChild(dom)
            }
            document.body.appendChild(dom);
        }

        var shareBtn = document.querySelectorAll(".share");
        if (shareBtn.length == 0) return false;
        for (var i = 0; i < shareBtn.length; i++) {
        
            shareBtn[i].onclick = function(event){
                event.preventDefault();
                createShare();
            }
        }
    }


    function scriptLoad( src, callback ){
        var script = document.createElement("script");
        script.src = src;
        document.documentElement.children[0].appendChild(script);
        script.onload = script.onreadystatechange = function(){
            if( !this.readyState || this.readyState === "loaded" ||    this.readyState === "complete"){
                    callback();
                }
            }
    }

})();